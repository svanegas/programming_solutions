/**
 *
 * @author salan403
 */
public class routing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hola");
    }
    
}
