#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <sstream>
#include <fstream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <map>
#include <set>
#include <bitset>

#define D(x) cout << #x " is " << x << endl

//157.253.238.31
//team608
//539207a2

using namespace std;

const double EPS = 1e-9;

template <class T> string toStr(const T &x)
{ stringstream s; s << x; return s.str(); }

template <class T> int toInt(const T &x)
{ stringstream s; s << x; int r; s >> r; return r; }

const int MAXN = 102;
bool sieve[MAXN + 3];
vector<int> primes;
int n;

void
build_sieve() {
  memset(sieve, false, sizeof(sieve));
  sieve[0] = sieve[1] = true;
  
  for (int i = 2; i * i <= MAXN; i++) {
    if (!sieve[i]) {
      for (int j = i * i; j <= MAXN; j += i) {
        sieve[j] = true; 
      } 
    } 
  }
  for (int i = 2; i <= MAXN; i++) {
    if (!sieve[i]) primes.push_back(i); 
  }
}

int
main() {
  build_sieve();
  while (cin >> n && n) {
    for (int i = 0; i < primes.size(); i++) {
      if (primes[i] > n) break;
      int sum = 0;
      for (int j = primes[i]; j <= n; j += primes[i]) sum += (sum + 1);
      cout << sum << " ";
    }
    puts("");
  }
  return 0;
}
